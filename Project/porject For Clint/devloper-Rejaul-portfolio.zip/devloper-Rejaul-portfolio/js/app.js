const slider = document.querySelector(".main-sliders");
const arowLeft = document.querySelector(".slider-icon .left");
const arowRight = document.querySelector(".slider-icon .right");
const buttonAni = document.querySelector(".btn-animation");
const htmlText = document.querySelector(".html-text");
const htmlcolor = document.querySelector(".html-collor");
const bar = document.querySelector(".bar");
const list_Item = document.querySelector(".list");
const Skills = document.querySelector(".my-skill");
const nav = document.querySelector("#hedder nav");
const Progresbar = document.querySelectorAll(".progres-bar");
const cursor = document.querySelector(".corsor");
const about_ani = document.querySelector(".about-inner");
const exprince_ani = document.querySelector(".exprince-animation");
const content_ani = document.querySelectorAll(".ani_mation");




// scrolling content effect
content_ani.forEach((e) =>{
  e.parentElement.style.overflow = 'hidden';
});
content_ani.forEach((e) => {
    e.classList.add("trsion");
    e.classList.remove("trsion");
});
document.addEventListener("scroll", () => {
  content_ani.forEach((e) => {
    if (window.innerHeight / 1.5 > e.getBoundingClientRect().top) {
      e.classList.add("trsion");
    } else {
      e.classList.remove("trsion");
    }
  });
});

// Nav bar
bar.onclick = () => {
  list_Item.classList.toggle("active");
};
// typing Effect
var typed = new Typed("#autoinput", {
  strings: ["Web Developer", "Ui Designer"],
  typeSpeed: 100,
  backSpeed: 200,
  loop: true,
});
// Skill animation
const skillSec = document.querySelector(".my-skill");

function showprog() {
  Progresbar.forEach((p) => {
    const value = p.dataset.progres;
    p.style.opacity = 1;
    p.style.width = `${value}%`;
  });
}
function heightprog() {
  Progresbar.forEach((p) => {
    p.style.opacity = 0;
    p.style.width = 0;
  });
}

let section = document.querySelectorAll(".scroul");
let nevLink = document.querySelectorAll("#hedder nav ul li a");

// Nav bar effect
if (window.scrollY > 0) {
  nav.classList.add("shadow");
} else {
  nav.classList.remove("shadow");
}

// scrolling all effect
window.onscroll = (w) => {
  // Nav bar effect
  if (window.scrollY > 0) {
    nav.classList.add("shadow");
  } else {
    nav.classList.remove("shadow");
  }

  section.forEach((sec) => {
    let top = window.scrollY;
    let offset = sec.offsetTop;
    let height = sec.offsetHeight;
    let id = sec.getAttribute("id");
    if (top >= offset && top < offset + height) {
      nevLink.forEach((link) => {
        link.children[0].classList.remove("navstyle");
        let linkId = document.querySelector(
          `#hedder ul li a[href*="${id}"] .linkcon `
        );
        linkId.classList.add("navstyle");
      });
    }
  });

  let sectionpos = skillSec.getBoundingClientRect().top;
  let screenpos = window.innerHeight / 2;
  if (sectionpos < screenpos) {
    showprog();
  } else {
    heightprog();
  }
};
// slider
var swiper = new Swiper(".mySwiper", {
  slidesPerView: 1,
  spaceBetween: 20,
  speed: 1000,
  loop: true,
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
  autoplay: {
    delay: 5000,
    waitForTransition: true,
  },
});